
CREATE TABLE `backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT NULL,
  `files_path` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `download_link` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8;

CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `description` longtext CHARACTER SET utf8 COLLATE utf8_general_ci,
  `mini_desc` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `href` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `public` int(10) unsigned DEFAULT '1',
  `meta_description` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `meta_title` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `h1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `meta_product_title1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `meta_product_title2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `meta_product_desc1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `meta_product_desc2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `pole1` text CHARACTER SET utf8 COLLATE utf8_bin,
  `pole2` text CHARACTER SET utf8 COLLATE utf8_bin,
  `pole3` text CHARACTER SET utf8 COLLATE utf8_bin,
  `pole4` text CHARACTER SET utf8 COLLATE utf8_bin,
  `pole5` text CHARACTER SET utf8 COLLATE utf8_bin,
  `bread_crumbs` text COLLATE utf8_bin,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `public` (`public`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
INSERT INTO `category` VALUES ('83', 'Документация', '', '', 'docs', '1', '', '', '', '2018-12-25 16:46:59', NULL, NULL, NULL, NULL, NULL, '', NULL, '', '', '', '', '', '');INSERT INTO `category` VALUES ('92', 'asdasd', '', '', 'asdasd', '1', '', '', '', '2019-01-25 14:27:11', NULL, NULL, NULL, NULL, NULL, '', NULL, '', '', '', '', '', '');INSERT INTO `category` VALUES ('96', 'Категория', '', '', 'kategoriya', '1', '', '', '', '2019-01-25 14:37:33', '2019-01-25 14:41:27', NULL, NULL, NULL, NULL, '', '55', '', '', '', '', '', '');
CREATE TABLE `geo_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_subdomain` int(11) DEFAULT NULL,
  `id_zone` int(11) DEFAULT NULL,
  `title` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `meta_title` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `meta_description` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `mini_desc` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `description` longtext CHARACTER SET utf8 COLLATE utf8_general_ci,
  `h1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `public` int(11) DEFAULT '0',
  `id_page` int(11) DEFAULT NULL,
  `id_cat` int(11) unsigned DEFAULT NULL,
  `main` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9769 DEFAULT CHARSET=utf8;

CREATE TABLE `geo_subdomain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_ru` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name_en` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `id_zone` int(11) DEFAULT '1',
  `yv` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `gv` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `adr` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `public` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `time` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
INSERT INTO `geo_subdomain` VALUES ('41', 'Владимир', 'vladimir', '6', NULL, NULL, '', '', '', '1', '', '2019-01-31 11:42:40');
CREATE TABLE `geo_zone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `public` int(1) DEFAULT '1',
  `default` int(1) DEFAULT NULL,
  `telephone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `worktime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
INSERT INTO `geo_zone` VALUES ('6', 'loc', '1', '1', '+7 4922 33-33-33', 'info@cms.loc', 'г.Владимир ул.Б.Московская д.1', 'Пн-Пт 11:00-20:01', '2018-12-25 14:42:29');
CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `name_en` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `public` int(11) DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

CREATE TABLE `menu_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `id_menu` int(11) DEFAULT NULL,
  `href` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `position` int(11) DEFAULT '1000',
  `id_sub` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=282 DEFAULT CHARSET=utf8;

CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `ref` longtext CHARACTER SET utf8 COLLATE utf8_general_ci,
  `time` datetime DEFAULT NULL,
  `url` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `ip_user` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `agent_user` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone_operator` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone_region` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ip_city` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ip_region` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `client_id` int(11) DEFAULT NULL,
  `check_s` int(11) DEFAULT '0',
  `send` int(11) DEFAULT '0',
  `keywords` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `startUrl` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;

CREATE TABLE `page_relink` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `main_id` int(11) DEFAULT NULL,
  `donor_id` int(11) DEFAULT NULL,
  `ankor` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `public` int(11) DEFAULT '1',
  `main_type` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `donor_type` varchar(1) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` int(11) DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `mini_desc` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `href` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `id_category` int(11) DEFAULT '0',
  `avatar` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `public` int(11) DEFAULT '1',
  `meta_title` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `meta_description` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `bread_crumbs` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `h1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `id_user` int(1) DEFAULT '1',
  `pole1` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `pole2` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `pole3` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `pole4` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `pole5` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `id_category` (`id_category`) USING BTREE,
  KEY `public` (`public`) USING BTREE,
  KEY `title` (`title`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12148 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
INSERT INTO `product` VALUES ('12145', NULL, 'Главная страница', '', '<p id=\"text\"><b>PBNcms</b>&nbsp;- гибкая система для управление сайтом, разработанная под потребности современного рынка продаж.&nbsp;<br />\nВ преимущества можно добавить следующие плагины: построение поддоменой сети (PBN) в рамках нескольких зон для продажи продукции по всей России с автоматической генерацией контента. Встроенный тег менеджер дает возможность добавлять на сайт нужные скрипты без знаний кода, а перелинковка страниц и добавление мета тегов при создании страницы облегчает головную боль вебмастера и экономит ваши затраты.</p>\n\n<p><i><b>Не является</b>&nbsp;свободно распространяемым программным обеспечением, программный продукт и его исходный код охраняются авторским правом</i></p>\n\n<p>Техническая поддержка:&nbsp;<a href=\"mailto:support@pbncms.ru\">support@pbncms.ru</a></p>\n\n<p>Актуальная версия:&nbsp;<b>2.0</b></p>\n', 'index', '0', '', '1', 'Документация PBNcms', 'Документация по настройке и использованию PBNcms', '', '2018-12-25 14:43:00', '2019-01-22 13:02:49', 'Документация PBNcms', '55', '', '', '', '', '');INSERT INTO `product` VALUES ('12146', NULL, 'Статическая страница', '', '', 'staticheskaya-stranica', '0', '', '1', '', '', '', '2018-12-25 14:44:10', NULL, 'Статическая страница', '1', '', '', '', '', '');INSERT INTO `product` VALUES ('12147', NULL, 'Шаблонизатор', '', '<p>Данный модуль позволяет произвести гибкие настройки шаблона. Вывести необходимы материал в нужных местах или подставить данные с помощью тегов</p>\n\n<h2>Параметры</h2>\n\n<p>Основные параметры задаются вфайле&nbsp;<i>config.php&nbsp;</i>который находится в папке с сайтом</p>\n\n<table class=\"table table-bordered table-hover table-active\">\n	<thead>\n		<tr>\n			<th scope=\"col\">Название</th>\n			<th scope=\"col\">Значение</th>\n			<th scope=\"col\">По умолчанию</th>\n		</tr>\n	</thead>\n	<tbody>\n		<tr>\n			<td><b>define(&#39;TEMPLATE&#39;,&#39;default&#39;)</b></td>\n			<td>Название папки с шаблоном для сайта&nbsp;(сейчас default)</td>\n			<td>&nbsp;default</td>\n		</tr>\n		<tr>\n			<td><b>define(&#39;JS&#39;,&#39;/public/js/&#39;)</b></td>\n			<td>Путь до папки js-скриптами</td>\n			<td>/public/js/</td>\n		</tr>\n		<tr>\n			<td><b>define(&#39;CSS&#39;,&#39;/public/css/&#39;)</b></td>\n			<td>Путь до папки со стилями css</td>\n			<td>/public/css/</td>\n		</tr>\n		<tr>\n			<td><b>define(&#39;IMG&#39;,&#39;/public/images/&#39;)</b></td>\n			<td>Путь до папки с картинками для темы</td>\n			<td>/public/images/</td>\n		</tr>\n	</tbody>\n</table>\n\n<h2>Файлы</h2>\n\n<p>В шаблоне по умолчанию используются заданные имена файлов для отображения пользователю</p>\n\n<table class=\"table table-bordered table-hover table-active\">\n	<tbody>\n		<tr>\n			<td>Имя</td>\n			<td>Модуль</td>\n			<td>Сквозная подгрузка</td>\n		</tr>\n		<tr>\n			<td>\n			<p><b>header.tpl</b></p>\n			</td>\n			<td>Вверхяя часть сайта</td>\n			<td>Да</td>\n		</tr>\n		<tr>\n			<td><b>menu.tpl</b></td>\n			<td>Навигация</td>\n			<td>Да</td>\n		</tr>\n		<tr>\n			<td><b>index.tpl</b></td>\n			<td>Главная страница</td>\n			<td>&nbsp;</td>\n		</tr>\n		<tr>\n			<td><b>category.tp</b></td>\n			<td>Категория</td>\n			<td>&nbsp;</td>\n		</tr>\n		<tr>\n			<td><b>product.tpl</b></td>\n			<td>Страница с привязкой к категории</td>\n			<td>&nbsp;</td>\n		</tr>\n		<tr>\n			<td><b>static.tpl</b></td>\n			<td>Статическая страница (например, о компании)</td>\n			<td>&nbsp;</td>\n		</tr>\n		<tr>\n			<td><b>404.tpl</b></td>\n			<td>Шаблон неверного URL</td>\n			<td>&nbsp;</td>\n		</tr>\n		<tr>\n			<td><b>sitemap_xml.tpl</b></td>\n			<td>Динамическая карта сайта в формате xml</td>\n			<td>&nbsp;</td>\n		</tr>\n		<tr>\n			<td><b>rss_xml.tpl</b></td>\n			<td>Динамический RSS с разметкой яндекс-турбо страниц</td>\n			<td>&nbsp;</td>\n		</tr>\n		<tr>\n			<td><b>scripts.tpl</b>&nbsp;</td>\n			<td>При включенном кэше подгружается всегда скрипты с динамическими параметрами</td>\n			<td>Да</td>\n		</tr>\n		<tr>\n			<td><b>footer.tpl</b></td>\n			<td>Нижняя часть - подгружается на всех страницах сайта</td>\n			<td>Да</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<p>Для любой страницы можно создать свой шаблон по его URL.</p>\n\n<p>Для примера, у нас есть потребность создать уникальный шаблон для страницы <em>контакты&nbsp;</em>и для всех страницы категории&nbsp;<em>блог.</em></p>\n\n<p>Мы знаем, что URL у страницы <em>контакты&nbsp; -&nbsp;</em><strong>contacts </strong>поэтому создаем в папке с темой файл с именем&nbsp;<strong>contacts.tpl</strong></p>\n\n<p>Теперь рассмотрим процесс создания шаблона для всех страниц в категории&nbsp;<em>блог, </em>URL - <strong>blog, </strong>создадим файл в папке с темой&nbsp;<strong>blog_category.tpl</strong></p>\n\n<h2>Теги</h2>\n\n<p>С помощью тегов в шаблоне&nbsp; можно выводить поля, для вывода тега заключите его в скобки например, тег&nbsp;<em>{meta_title}</em></p>\n\n<table class=\"table table-bordered table-hover table-active\">\n	<tbody>\n		<tr>\n			<td>Имя</td>\n			<td>Описание</td>\n		</tr>\n		<tr>\n			<td><b>meta_title</b></td>\n			<td>Поле meta title, предназначен для вывода в теге&nbsp;<b>&lt;title&gt;</b></td>\n		</tr>\n		<tr>\n			<td><b>meta_description</b>&nbsp;</td>\n			<td>Поле Meta description, предназначен для вывода в теге meta атрибут content</td>\n		</tr>\n		<tr>\n			<td><b>telephone</b></td>\n			<td>поле телефон, задается при создании&nbsp;зоны&nbsp;или&nbsp;поддомена</td>\n		</tr>\n		<tr>\n			<td><b>address</b></td>\n			<td>поле адрес, задается при создании&nbsp;зоны&nbsp;или&nbsp;поддомена</td>\n		</tr>\n		<tr>\n			<td><b>email</b></td>\n			<td>поле e-mail, задается при создании&nbsp;зоны&nbsp;или&nbsp;поддомена</td>\n		</tr>\n		<tr>\n			<td><b>h1</b></td>\n			<td>поле H1, предназначен для вывода в теге H1</td>\n		</tr>\n		<tr>\n			<td><b>description</b></td>\n			<td>Основной текст страницы</td>\n		</tr>\n		<tr>\n			<td><b>mini_description</b></td>\n			<td>Краткое описание страницы</td>\n		</tr>\n		<tr>\n			<td><b>avatar</b></td>\n			<td>Поле &quot;Путь до фото&quot;</td>\n		</tr>\n		<tr>\n			<td><b>pole1 - pole5</b></td>\n			<td>5 дополнительных полей</td>\n		</tr>\n		<tr>\n			<td><b>scripts_header</b></td>\n			<td>Список скриптов у которых позиция header</td>\n		</tr>\n		<tr>\n			<td><b>scripts_footer</b></td>\n			<td>Список скриптов у которых позиция footer</td>\n		</tr>\n		<tr>\n			<td><b>content_of_article</b></td>\n			<td>Выводит содержимое статьи на основании тегов h2</td>\n		</tr>\n		<tr>\n			<td><b>id_category</b></td>\n			<td>Выводит числовой идентификатор категории</td>\n		</tr>\n		<tr>\n			<td><b>id_product</b></td>\n			<td>Выводит числовой идентификатор страницы</td>\n		</tr>\n		<tr>\n			<td><b>title</b></td>\n			<td>Поле &quot;название&quot;</td>\n		</tr>\n		<tr>\n			<td><b>title_category</b></td>\n			<td>Название категории</td>\n		</tr>\n	</tbody>\n</table>\n\n<p>&nbsp;</p>\n\n<h2>Запросы</h2>\n\n<p>В файле шаблона можно формировать запрос к базе данных для вывода нужного материала</p>\n', 'template', '83', '', '1', 'Настройка шаблона для сайта', 'Настройка шаблона для сайта в cms', '', '2019-01-22 17:11:57', '2019-01-22 18:51:32', 'Шаблонизатор', '55', '', '', '', '', '');
CREATE TABLE `redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `to` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `create_date` datetime DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `public` int(255) DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;
INSERT INTO `setting` VALUES ('16', 'cache', '{\"status\":1}');INSERT INTO `setting` VALUES ('18', 'extredirect', '0');
CREATE TABLE `users` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `password` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `surname` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `role` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `last_in` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `api` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `comment` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `active` int(10) DEFAULT '1',
  `api_key` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
INSERT INTO `users` VALUES ('56', 'f5d1278e8109edd94e1e4197e04873b9', 'e10adc3949ba59abbe56e057f20f883e', 'Иван', 'Иванов', 'admin', '2019-01-11 16:26:17', 'yes', 'тестер', '1', 'e3f9e0a7583393b05dd9c94d0571e286');INSERT INTO `users` VALUES ('55', '21232f297a57a5a743894a0e4a801fc3', '21232f297a57a5a743894a0e4a801fc3', 'Алексей', '', 'admin', '2019-01-31 13:31:31', 'no', '', '1', NULL);
CREATE TABLE `users_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `method` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `text` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
INSERT INTO `users_logs` VALUES ('40', '2019-01-31 11:42:40', 'web', 'Добавил новый поддомен vladimir в зоне loc', '55');